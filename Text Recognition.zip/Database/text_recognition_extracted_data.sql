CREATE DATABASE  IF NOT EXISTS `text_recognition` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `text_recognition`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: text_recognition
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `extracted_data`
--

DROP TABLE IF EXISTS `extracted_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extracted_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `data` datetime DEFAULT CURRENT_TIMESTAMP,
  `extracted_text` text,
  `image` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extracted_data`
--

LOCK TABLES `extracted_data` WRITE;
/*!40000 ALTER TABLE `extracted_data` DISABLE KEYS */;
INSERT INTO `extracted_data` VALUES (11,'2024-02-16 18:44:34','python\n',_binary 'G:/Images/23580846fad45c91d178ff126cabb915_icon.png'),(12,'2024-02-16 18:45:12','IS FUTURE\n\nPython Developer\n\n& +923402480258 9 WM cOmannane@gmail.com\n',_binary 'G:/Images/c6mannan@gmail.com (1).png'),(13,'2024-02-16 18:57:59','Smart Watches\n\nGet free shipping on\nselected Products\n\n',_binary 'G:/Images/Shop Online img/1.jpg'),(14,'2024-02-16 19:01:07','J File Edit Selection View Go Run ~~ €> | BP children_shop2 oogae — x\n\noO EXPLORER ®@ viewspy x — dj indexhtml bpreou~\nCHILDREN _SHOP2 app > @ viewspy > @ index\nOP? mM mesienses 205 return render(request, ‘seller.html\")\n> tll migrations 206\np > sli templatetags 207\n208 © def seller_order(request, email):\nint ~ 3\noe 209 | seller_email = request.session.get( ‘seller_enail\')\nb> =a no orders = Order objects.filter(seller_enail=seller_enail).order_by(\"-order_place date\")\nbs @ eppspy m1 if request.method == ‘POST*\n® helperspy nz if ‘show details’ in request. POST\nas ® modelspy 213 product_id = request.POST.get(*show details’)\n@ testspy na request session ‘show details product_id\'] = product_id\nA @ urspy 2s return redirect(‘seller_order_show_details\', email-seller_enail) ;\n216 nn render(request, ‘seller_order.html\', {‘orders\': orders, ‘email’: seller_email})\n* ma 27\n© st chidren shop? oo\n> WB _pycache_ 219 def seller_order_show_details(request, email):\n@ _init_py 220 enail = enail.strip()\n@ assiy 2a show details product id = request.session{ “show_details_product_id\"]\nSemen 222 order = Order objects. filter (order_id-show_details_product_id).first()\n@ wispy ne\n224 iF request method == ‘POST*:\n@ wssipy 225 if ‘save_edit\' in request.POST:\n> al media 226 completed = request .POST.get(‘ completed\")\n> tit Static 227 iF completed == ‘on\nYs Templates 228 order completed = True\nG) abouthimi 29 order.save()\nara 20 SSSSS EEE Soe Sees)\na return redirect(‘seller_order*, enail-enai\nJee 232 elif completed None:\ncarts 233 order.completed = False\ndj change_password.htmi 234 order.save()\n\n4) customer orderntm!\n4) edit productntm!\n4) forgot password.htm! [25/0ct/2023 14:\n\nOUTPUT PROBLEMS DEBUGCONSOLE TERMINAL PORTS\n\n243] “GET /media/ HTTP/1.1\" 404 7290\n\n4 index Not Found: /media/\nOca (25/Oet/ 2023 14:59:49] “GET media HITP/L.A\" 408 7290\nproduct detail =\n\nQ@ ai sears\n\n\\Django Projects\\children_shop2>\n\n@ OUTLINE\n\n> TIMELINE\n',_binary 'G:/Images/Fiverr/Web Development/professional django developer for dynamic websites3.png'),(15,'2024-02-16 19:32:26','Web Scraping\n\ne Data Extraction\n\ne Data Mining\n\n@ Python Web Scraping\ne Data Entry\n\ne Ecommerce Websites\ne Shopify, Woocommerce\n\ne Scrapy & Selenium\n\n',_binary 'G:/Images/Fiverr/Web Scraping/do python web scraping, data scraping, data extraction 3.png'),(18,'2024-02-17 13:04:58','@ Children Shop — feHome Clothing ~ Accessories Objects + Sell On Children Shop _| &« Contact Us BO smyprofiie\n\nSearch in Children Shop\n\nSeller Profile\n\nName:\n\nAbdul Mannan\n\nMobile Number:\n88888888\n\nEmail ID:\n\nabdimanan258@gmail.com\n\nAddress (home):\n\nFaisalabad\n\nPassword\n\nUpload Product\n\n(E25)\n(eam)\n\nAbout Us Quick Links Let Us Help You Make Money With Us\n\nYour ultimate Children Shop Kids Clothing © Your Account © Sell on Children Shop\n\ndestination! We offer a wide range Baby Clothing\n\nof products across. _various Accessories\ncategories including Kids Clothing, Play Room\nBaby Clothing, Toys and all other Swimwear\naccessories.\n\nYour Company. All Rights Reserved.\n\n',_binary 'G:/Images/Children Shop 2 img/Seller Profile Page.png'),(19,'2024-02-17 13:34:32','Title of your Slide\n\n* The quick brown fox jumps over the lazy dog. The quick\nbrown fox jumps over the lazy dog. The quick Brown fox\njumps over the lazy dog. The quick brown fox jumps over\nthe lazy dog. The quick brown fox jumps over the lazy dog.\n\n* The quick brown fox jumps over the lazy dog. The quick\nbrown fox jumps over the lazy dog. The quick brown fox\nJumps over the lazy dog. The quick brown fox jumps over\n\nthe lazy dog. The quick brown fox jumps over the lazy dog.\n\n* The quick brown fox jumps over the lazy dog. The quick\nbrown fox jumps over the lazy dog. The quick brown fox\njumps over the lazy dog, The quick brow fox jumps over\n\nthe lazy dog. The quick brown fox jumps over the lazy dog.\n\n©AILPPT-Templates.com\n',_binary 'C:/Users/DELL/Downloads/generated-random-text.jpg'),(20,'2024-02-17 13:34:39','~-shehasnootherneurologicsymptomsnonumbnessortinglingshedeniesanyvisualcha\nngespastmedicalhistorygallbladderremovalpastsurgicalhistorydiabetesrheumatoida\nrthritishypertensiongerdandhypothyroidismmedicationsadvairalbuterolallopurinol\naspirinclobetasolfolicacidfosamaxlevoxyllisinoprilmetforminomeprazoleplaquenilp\nrednisonetestosteroneverapamilallergiesnoknowndrugallergiessocialhistorythepati\nentismarriedwithchildshedoesnotsmokeshedoesnotdrinkshedoesnotuserecreation,\naldrugssheweighspoundsandisinchestallfamilyhistorynegativeforbrainaneurysmoro\ntheraneurysmitwasalsonegativeforheartdiseasehighcholesterolandhypertensionand\nnegativefordiabetesreviewofsystemsthepatientispositiveforhypertensionswellingint\nhehandsorfeetlegpainwhilewalkingasthmapneumoniashortnessofbreathgastritisule\nersdiabetesthyroiddiseaseurinarytractinfectionsandthosesymptomsrelatedtothepre\nsentillnessthedetailsofthereviewofsystemswerereviewedwiththepatientandareinclu\ndedintheneurosurgicalhealthhistoryquestionnairepainthepatienthasepisodicjointpa\ninthatistreatedwithtylenolthepatientdoesnothaveanynutritionalconcernsshedoesno\nthaveanysafetyconcernsphysicalexamination...\n',_binary 'C:/Users/DELL/Downloads/An_example_for_a_nailed_note.jpg');
/*!40000 ALTER TABLE `extracted_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-17 14:04:06
